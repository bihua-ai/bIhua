# my_package/hello.py

def hello_world():
    return "Hello from function hello_world in module hello.py"
