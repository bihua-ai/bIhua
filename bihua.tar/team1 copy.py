from agent_service import BihuaAgentService

# from bihua import BihuaAgentService
import asyncio

# admin access token = syt_YWRtaW4_JyaVfBhsOyLrhnfixJZv_1kRUM1


# group_alias = "#boot_team001:messenger.b1.shuwantech.com"
bihua_agent_service_config_location = "/opt/bihua/data/config"
group_alias = "#bot_org3:messenger.b1.shuwantech.com"
group_topic = "Bot Team 1"  # this will only be used if the group is created, otherwise, it will be ignored
agent_dir_path = "/opt/bihua_cient/agents"  # Make sure to define the agent dir path


async def agent_group_runner(group_alias, group_topic, agent_dir_path, bihua_agent_service_config_location):
    agent_service = BihuaAgentService(bihua_agent_service_config_location, )  # Create the app service
    await agent_service.agent_group_runner(group_alias, group_topic, agent_dir_path)


# Entry point to ensure async function runs
if __name__ == "__main__":
    # Ensure the code runs within the existing event loop
    asyncio.run(agent_group_runner(group_alias, group_topic, agent_dir_path))
